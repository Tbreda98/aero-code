%% Computational Assignment #4: Prandtl Lifting Line Theory
%{
Author: Timothy Breda
Collaborrators: Kyle Li, Michael Vogel, Sam Taylor, Tyler Pirner
Class: ASEN 3111-011 Aerodynamics
Date Created: 11/11/2019
Date Due: 11/21/19
Objective:  The objective of this script is to run my functions and output
            e, C_L and C_Di for the entire wing as described in the PDF. Also, the
            convergence is determined to describe the error associated with this
            problem. Lastly, the function PLLT is called in a nested for
            loop to examine the effects of varying taper ratio and aspect
            ratio on the span efficiency factor.
Units:  Imperial units is used 

%}
%% Housekeeping
clc;clear;close all

% adding paths
 addpath('Comp Assignment 3')

%% Comp Assignment 3 Results

% These Results were found by running the vortex panel code for the tip and
% the root NACA airfoils. This is done to avoid long computational times,
% as directed by Professor Farnsworth. 
% converting to radians
aero_t = -.0544*(pi/180);
aero_r = -2.1557*(pi/180);
% making this 2pi for greater accuracy
a0_t = 2*pi;
a0_r = 2*pi;
% y intercept of linear lift vs alpha equation as found in CA3
b0_t = .0065;
b0_r = .2596;
%% Problems 1 & 2: PLLT for Specific Case

% Variable inputs for PLLT
N = 100;
b = 100; %(ft)
c_r = 15; %(ft)
c_t = 5;  %(ft)
geo_r = 5*pi/180; %(rads)
geo_t = 0; %(rads)

% function call
[e,c_L,c_Di,Lift,Di] = PLLT(b,a0_t,a0_r,c_t,c_r,aero_t,aero_r,geo_t,geo_r,N);

% displaying results for c_L and c_Di to grader
disp('The coefficient of lift for the wing in problem#2 is:  ')
disp(c_L)
disp('The coefficient of induced drag for the wing in problem#2 is:  ')
disp(c_Di)
%% Problem 2: Convergence
% these are absolute answers used for error calc determined from N = 10000,
L_abs = 21815;
Di_abs = 378.6847;

tol1 = .05;
tol2 = .01;
tol3 = .001;
test = 1;
% Lift convergence testing
for i = 1:100
    [e,c_L,c_Di,Lift,Di] = PLLT(b,a0_t,a0_r,c_t,c_r,aero_t,aero_r,geo_t,geo_r,i);
        if (abs(L_abs - Lift)/L_abs) < tol1 && test ==1
            conv1 = i;
            test = 2;
        elseif (abs(L_abs - Lift)/L_abs) < tol2 && test==2
            conv2 = i;
            test = 3;
        elseif (abs(L_abs - Lift)/L_abs) < tol3 && test==3
            conv3 = i;
            test = 4;
        end
end
test = 1;
% Induced Drag Convergence testing
for i = 1:100
    [e,c_L,c_Di,Lift,Di] = PLLT(b,a0_t,a0_r,c_t,c_r,aero_t,aero_r,geo_t,geo_r,i);
        if (abs(Di_abs - Di)/Di_abs) < tol1 && test ==1
            conv4 = i;
            test = 2;
        elseif (abs(Di_abs - Di)/Di_abs) < tol2 && test==2
            conv5 = i;
            test = 3;
        elseif (abs(Di_abs - Di)/Di_abs) < tol3 && test==3
            conv6 = i;
            test = 4;
        end
end
% displaying lift convergence to grader
disp('The number of odd terms required to converge lift within 5% error is:   ')
disp(conv1)
disp('The number of odd terms required to converge lift within 1% error is:   ')
disp(conv2)
disp('The number of odd terms required to converge lift within .1% error is:   ')
disp(conv3)
% displaying induced drag convergence to grader
disp('The number of odd terms required to converge induced drag within 5% error is:   ')
disp(conv4)
disp('The number of odd terms required to converge induced drag within 1% error is:   ')
disp(conv5)
disp('The number of odd terms required to converge induced drag within .1% error is:   ')
disp(conv6)

%% Problem 3: Varying Aspect ratio and Taper ratio
% defining geotwist to be zero as told in the problem
geo_r = 0;
geo_t = 0;
aero_r = .000000001;
aero_t = .000000001;

% defining aspect ratios and taper ratio scales
AR = [4 6 8 10]';

% From calculations for c_r and c_t from keeping AR constant
c_t = linspace(0,1,100);
c_r = 2 - c_t;
taper = c_t./c_r;



% span calculation based on changing ARs and taper ratios


% this nested for loop calculates matrices for e, c_L, and c_Di in terms of
% varying taper ratios and varying aspect ratios
for i = 1:length(AR)
    b = AR(i);
    for j = 1:length(c_r)
        [e_mat(i,j),c_L_mat(i,j),c_Di_mat(i,j)] = PLLT(b,a0_t,a0_r,c_t(j),c_r(j),aero_t,aero_r,geo_t,geo_r,50);
    end
    % plotting the results from varying taper ratio and AR
    hold on
    figure(1)
    hold on
    plot(taper,e_mat(i,:),'DisplayName',['AR', num2str(AR(i))])
    title('Effect of varying AR and Taper Ratio on Span Efficiency');
    xlabel('Taper Ratio');ylabel('Span efficiency');
    legend;
end

 %% Functions Called
% The following functions were built and called as part of this assignment.
%
% <include>PLLT.m</include>