%{
Author: Timothy Breda
Collaborators: Kyle Li, Michael Vogel, Sam Taylor, Tyler Pirner
Objective: The objective of this function is to be able to compute the span
           efficiency factor, lift coefficient, and drag coefficient given
           the input variables. 

%}

function [e,c_L,c_Di,Lift,Di] = PLLT(b,a0_t,a0_r,c_t,c_r,aero_t,aero_r,geo_t,geo_r,N)

%% Vector Creation

% creating vectors that are the entire length of the wing
alpha = zeros(1,N);
c = zeros(1,N);
zeroL_AoA = zeros(1,N);
theta = zeros(1,N);

% this theta is important in iterating later
for i = 1:N
    theta(i) = (i*pi)/(2*N);
end
% flipping theta so the root is pi/2
theta = flip(theta);
for i = 1:N
    c(i) = c_r - (c_r - c_t)*cos(theta(i));
    zeroL_AoA(i) = aero_r - (aero_r - aero_t)*cos(theta(i));
    alpha(i) = geo_r - (geo_r - geo_t)*cos(theta(i));
end

% Flow Variables
% conversion from mph to ft/s
mph2fps = 5280/3600;
V_inf = 150*mph2fps; %(ft/s)
rho_inf = 0.0023769; % slug/ft^3
q_inf = .5*rho_inf*V_inf^2;


%% Setting Up Linear System

% creating right hand side, or b matrix as i call it
b_matrix = zeros(N,1);
for i = 1:N
    b_matrix(i) = alpha(i) - zeroL_AoA(i);
end

% setting up A matrix
A_matrix = zeros(N,N);
% rows (i) go by theta
% columns (j) go by An

% this nested for loop is creating the prandlt matrix to be used in solving
% for the fourier coefficients

for i = 1:N
    for j = 1:N
        % creating the A matrix in terms of Ax = b using the lifting line
        % equation
        A_matrix(i,j) = (4*b/(a0_r*c(i)))*sin((2*j-1)*theta(i)) + (2*j-1)*(sin((2*j-1)*theta(i))/sin(theta(i)));
        
    end
end

% this vector is the vector of fourier coefficients
A_n = A_matrix\b_matrix;
A1 = A_n(1);
% delta calculation based on equation found in Anderon chp. 5
delta = 0;
for i = 2:N
    delta = delta + (2*i-1)*(A_n(i)/A1)^2;
end


% planform area calc
S = (((c_r+c_t)/2)*50)*2;
AR_prob2 = b^2/S;

% calculations based on equations found in chapter 5 of Anderson
e = 1/(1+delta);
c_L = A_n(1)*pi*AR_prob2;
c_Di = c_L^2/(pi*e*AR_prob2);
Lift = c_L*q_inf*S;
Di = c_Di*q_inf*S;



end




