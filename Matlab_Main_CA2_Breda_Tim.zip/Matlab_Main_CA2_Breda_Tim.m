%% ASEN 3111 - Aerodynamics - Computational Assignment #2
tic
%{
Author: Timothy Breda
Collaborators: Sam Taylor
               Michael Vogel
               Kyle Li
               James Tiver
Due date: 10/10/2019

Purpose: The purpose of this computational assignment is to model flow
around a thin airfoil by computing and plotting streamlines, equipotential
lines, and pressure contours.

%}

%% Housekeeping
clc;
clear;
close all;
%% Variable Declaration

% These variables will be passed into the function

c = 2;                %(m)
alpha = (12*pi/180);  %(rads)
V_inf = 68;           %(m/s)
rho_inf = 1.225;      %(kg/m^3)
p_inf = 101.3e3;      %(Pa)
% Number of Discrete Vortices
N = 200;



%% Case 1 Function Call (Problem 1)
% this part is primarily to output a sublot of the streamlines,
% equipotential lines, and pressure contour

% "problem" is used to switch from case to case
problem = 1;
% "pic" is used to eventually iterate through to output multiple sublots
pic = 1;
[Velocity,Pressure,Max_V,Min_V,Max_P,Min_P] = Plot_Airfoil_Flow(c,alpha,V_inf,p_inf,rho_inf,N,problem,pic);
 
%% Case 2 Function Call (Problem 2) 
% problem is used to switch from case to case
problem = 2;
% Preallocation for speed 
count = 1;
Error_Pmin = zeros(1,5);
Error_Pmax = zeros(1,5);
Error_Vmin = zeros(1,5);
Error_Vmax = zeros(1,5);
min_P = zeros(1,5);
max_P = zeros(1,5);
min_V = zeros(1,5);
max_V = zeros(1,5);
% This is a for loop which gathers the min and max p and v values at
% various numbers of panels in order to compute relative error
for N = 1000:1000:5000
    [Velocity,Pressure,Max_V,Min_V,Max_P,Min_P] = Plot_Airfoil_Flow(c,alpha,V_inf,p_inf,rho_inf,N,problem,pic);
    min_P(count) = Min_P;
    max_P(count) = Max_P;
    min_V(count) = Min_V;
    max_V(count) = Max_V;
    count = count+1;
end
% Using Relative error to find error for max and min pressure and velocity
for i = 1:5
    Error_Pmin(i) = (min_P(i) - min_P(length(Error_Pmin)))/min_P(length(Error_Pmin));
    Error_Pmax(i) = (max_P(i) - max_P(length(Error_Pmax)))/max_P(length(Error_Pmax));
    Error_Vmin(i) = (min_V(i) - min_V(length(Error_Vmin)))/min_V(length(Error_Vmin));
    Error_Vmax(i) = (max_V(i) - max_V(length(Error_Vmax)))/max_V(length(Error_Vmax));
end
disp('Error in max pressure:  ')
disp(Error_Pmax)
disp('Error in min pressure:  ')
disp(Error_Pmin)
disp('Error in min velocity:  ')
disp(Error_Vmin)
disp('Error in max velocity:  ')
disp(Error_Vmax)
disp('Qualitative explanation for error from #2:   ');
disp('Since this error is relative, it will converge to zero as the largest number of intervals is assumed to have a true value.')
disp('We can see that the error decreases (or increases for negative values) with number of intervals as the calculations are more accurate with more intervals')
disp('because it is more representative of a physical solid plate.')

%% Case 3 Function Call (Problem 3)
 % to call the function and loop through for different c alpha and v inf
 
 % problem is used to switch from case to case
problem = 3;
% Here pic is a value to use inside figure() such that subplots will be
% saved seperately for each changed value instead of as single separate figures
pic = 2;
% Outputting plots with the chord as 1,3, and 5 meters
 for i = 1:2:5
  c = i;
  Plot_Airfoil_Flow(c,alpha,V_inf,p_inf,rho_inf,N,problem,pic);
  pic = pic+1;
 end
 % Resetting the chord length
 c = 2;
 % Outputting plots with the alpha as -20, 0, 25 meters
 for i = -10:20:30
  alpha = i*pi/180;
  Plot_Airfoil_Flow(c,alpha,V_inf,p_inf,rho_inf,N,problem,pic);
  pic = pic+1;
 end
 % Resetting alpha
 alpha = (12*pi/180);
 % Outputting plots with the V_inf as 50,100, and 150 m/s
  for i = 50:50:150
  V_inf = i;
  Plot_Airfoil_Flow(c,alpha,V_inf,p_inf,rho_inf,N,problem,pic);
  pic = pic+1;
  end
 
  disp('Qualitative explanation of results from #3:  ')
  disp('As the chord length increases, the magnitude of the velocity potential increases at both the leading and trailing edge.')
  disp('Similar to the velocity potential, the stream function magnitude increase with chord increase.')
  disp('We can see there is a greater distance between streamlines and equipotential lines with chord increase.')
  disp('When it comes to the change in alpha, a more extreme positive angle yields greater distance between SLs and EP lines.')
  disp('The magnitude of the EP and SLs for changing alpha do not change with regards to corresponding points.')
  disp('Changes in velocity do not change the EPs or SLs, but the magnitude does change.')
 toc
 %% Functions Called
% The following functions were built and called as part of this assignment.
%
% <include>Plot_Airfoil_Flow.m</include>