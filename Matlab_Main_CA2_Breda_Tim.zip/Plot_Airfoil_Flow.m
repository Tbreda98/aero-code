function [Velocity,Pressure,Max_V,Min_V,Max_P,Min_P] = Plot_Airfoil_Flow(c,alpha,V_inf,p_inf,rho_inf,N,problem,pic)
%{
Author:    Timothy Breda
Collaborators: Sam Taylor
               Michael Vogel
               Kyle Li
               Zach Tiver
Due Date:  10/10/19
Purpose:   The purpose of this function is to compute flow around an airfoil
           in terms of computing stream function, velocity potential, and pressure
           distrobution. 
Objective: The objective of this function is to plot streamlines,
           equipotential lines, and pressure contours for various values of
           alpha, c, and v_inf in order to compare the effects of changing
           these variables. 

%}
 
%% Defining the Domain for the meshgrid
xmin = -1.5;
xmax = 7.5;
ymin = -4.5;
ymax = 4.5;
%% Define Number of Grid Points for plot 
num_x = 80; % number of steps in the x direction
num_y = 80; % number steps in the y direction

%% Create mesh over domain using number of grid points specified
[x,y] = meshgrid(linspace(xmin,xmax,num_x),linspace(ymin,ymax,num_y));
%% Using switch to save computational time
% case 1 deals with problem 1, case 2 for problem 2, and so on
switch problem
    case 1


%% Flow Variable Definition
% Location of vortex
xGamma = linspace(.001,c,N); 
yGamma = linspace(0,0,N);
% Defining delta x
delx = diff(xGamma);
% Strength of the vortex sheet
gamma = 2*(alpha)*V_inf*((1 - xGamma/c)./(xGamma/c)).^0.5; 
% Defining the Strength of the Nth vortex
Gamma = gamma.*delx(1); 
%% Defining a function which calculates the radius.
% Radius function defined for use in polar coordinates
r= @(x,y,x1,y1) sqrt((x-x1).^2+(y-y1).^2);
%% Stream Function Calculation 
% Initializing stream function for allocation later
Total_Psi = 0;
% Calculating Psi for Uniform Flow based on the geometry for flow at a 12
% degree angle 
Psi_unif = -V_inf*x*sin(alpha) + V_inf*y*cos(alpha);

for i = 1:length(xGamma)
   % Calculating Psi for vortex flow
   Psi_vort = (Gamma(i)./(2*pi)).*log(r(x,y,xGamma(i),yGamma(i)));
   Total_Psi = Total_Psi + Psi_vort;
end 
    
% Adding Stream Functions using Superposition
Total_Psi = Total_Psi + Psi_unif;

%% Velocity Potential Calculation 
% Initializing total velocity potential
Total_Phi = 0;
% Defining velocity potential for uniform flow
Phi_unif = V_inf*x*cos(alpha) + V_inf*y*sin(alpha);
for i = 1:length(xGamma)
    Phi_vort = -Gamma(i)./(2*pi).*mod(atan2(y-yGamma(i),x-xGamma(i)),2*pi);
    Total_Phi = Total_Phi + Phi_vort;
end

% Adding velocity potentials using Superposition
Total_Phi = Total_Phi + Phi_unif;

%% Velocity and Pressure Calculations
% Initializing velocity in xy for vortex flow to be zero
V_vortx = 0; 
V_vorty = 0; 
% Initializing velocity in xy for uniform flow
V_unifx = ones(num_x) * V_inf*cos(alpha); 
V_unify = ones(num_y) * V_inf*sin(alpha);  

for i = 1:length(xGamma)
    % Velocity of Vortex from polar
    V_vort = -Gamma(i)./(2*pi*r(x,y,xGamma(i),yGamma(i))); 
    % Finding vortex x and y components
    V_vortx = V_vortx + V_vort.*cos((pi/2) + atan2(y - yGamma(i),x - xGamma(i)));  
    V_vorty = V_vorty + V_vort.*sin((pi/2) + atan2(y - yGamma(i),x - xGamma(i))); 
end
% Calculating magnitude of velocity at all points
Velocity = sqrt((V_vortx + V_unifx).^2 + (V_vorty + V_unify).^2);
% Coefficient of pressure as defined in the book
C_p = abs(1 - (Velocity/V_inf).^2);
% Pressure calculation
Pressure = p_inf + C_p*0.5*rho_inf*V_inf.^2; 
%% Data Parsing to find min and max P and V values
Max_V = max(Velocity(:));
Min_V = min(Velocity(:));
Max_P = max(Pressure(:));
Min_P = min(Pressure(:));
%% Determine color levels for contours
% defines the color levels -> trial and error to find a good representation
levmin = Total_Psi(1,num_x); 
levmax = Total_Psi(num_y,num_x);
levels = linspace(levmin,levmax,100)';
% Defining vectors which will be used in plotting
P_levels = linspace(Max_P,Min_P,100);
%% Plotting using above data
% Plotting Stream Function

% Plotting Stream Function
figure(1)
subplot(2,2,1)
contourf(x,y,Total_Psi,levels)
% Drawing line to represent thin airfoil
line([0,c],[0,0],'linewidth', 3) ;
% Window of plot and labels
xlim([-0.5 2.25]);ylim([-1.5 1.5]);
title('Stream Function around Thin Airfoil');
xlabel('X Distance (m)');ylabel('Y Distance (m)');
colorbar

% Plotting Equipotential lines
figure(1)
subplot(2,2,2)
contour(x,y,Total_Phi,levels)
% Drawing line to represent thin airfoil
line([0,c],[0,0],'linewidth', c) 
% Setting Window and labels
xlim([-1 2.25]);ylim([-1 1]);
title('Equipotential Lines around Thin Airfoil');
xlabel('X Distance (m)');ylabel('Y Distance (m)');
colorbar

% Plotting Pressure Countours 
figure(pic)
subplot(2,2,3)
contourf(x,y,Pressure,P_levels)
% Drawing line to represent thin airfoil
line([0,c],[0,0]) 
% Setting window and labels
xlim([-0.5 2.25]);ylim([-1.5 1.5]);
title('Pressure of Thin Air Foil');
xlabel('X Distance (m)');ylabel('Y Distance (m)');
colorbar
sgtitle(['SL and EP Lines at c ',num2str(c),'m,angle ',num2str(alpha),' rads,and V_i_n_f ',num2str(V_inf),' m/s']);
    case 2
        %% Flow Variable Definition
% Location of vortex
xGamma = linspace(.001,c,N); 
yGamma = linspace(0,0,N);
% Defining delta x
delx = diff(xGamma);
% Strength of the vortex sheet
gamma = 2*(alpha)*V_inf*((1 - xGamma/c)./(xGamma/c)).^0.5; 
% Defining the Strength of the Nth vortex
Gamma = gamma.*delx(1); 
%% Defining a function which calculates the radius.
% Radius function defined for use in polar coordinates
r= @(x,y,x1,y1) sqrt((x-x1).^2+(y-y1).^2);
%% Stream Function Calculation 
% Initializing stream function for allocation later
Total_Psi = 0;
% Calculating Psi for Uniform Flow based on the geometry for flow at a 12
% degree angle 
Psi_unif = -V_inf*x*sin(alpha) + V_inf*y*cos(alpha);

for i = 1:length(xGamma)
   % Calculating Psi for vortex flow
   Psi_vort = (Gamma(i)./(2*pi)).*log(r(x,y,xGamma(i),yGamma(i)));
   Total_Psi = Total_Psi + Psi_vort;
end 
    
% Adding Stream Functions using Superposition
Total_Psi = Total_Psi + Psi_unif;

%% Velocity Potential Calculation 
% Initializing total velocity potential
Total_Phi = 0;
% Defining velocity potential for uniform flow
Phi_unif = V_inf*x*cos(alpha) + V_inf*y*sin(alpha);
for i = 1:length(xGamma)
    Phi_vort = -Gamma(i)./(2*pi).*mod(atan2(y-yGamma(i),x-xGamma(i)),2*pi);
    Total_Phi = Total_Phi + Phi_vort;
end

% Adding velocity potentials using Superposition
Total_Phi = Total_Phi + Phi_unif;

%% Velocity and Pressure Calculations
% Initializing velocity in xy for vortex flow to be zero
V_vortx = 0; 
V_vorty = 0; 
% Initializing velocity in xy for uniform flow
V_unifx = ones(num_x) * V_inf*cos(alpha); 
V_unify = ones(num_y) * V_inf*sin(alpha);  

for i = 1:length(xGamma)
    % Velocity of Vortex in polar
    V_vort = -Gamma(i)./(2*pi*r(x,y,xGamma(i),yGamma(i))); 
    % Converting vortex velocities to cartesian
    V_vortx = V_vortx + V_vort.*cos((pi/2) + atan2(y - yGamma(i),x - xGamma(i)));  
    V_vorty = V_vorty + V_vort.*sin((pi/2) + atan2(y - yGamma(i),x - xGamma(i))); 
end
% Calculating magnitude of velocity at all points
Velocity = sqrt((V_vortx + V_unifx).^2 + (V_vorty + V_unify).^2);
% Coefficient of pressure as defined in the book
C_p = abs(1 - (Velocity/V_inf).^2);
% Pressure calculation
Pressure = p_inf + C_p*0.5*rho_inf*V_inf.^2; 
%% Data Parsing to find min and max P and V values
Max_V = max(Velocity(:));
Min_V = min(Velocity(:));
Max_P = max(Pressure(:));
Min_P = min(Pressure(:));

    case 3
        %% Flow Variable Definition
% Location of vortex
xGamma = linspace(.001,c,N); 
yGamma = linspace(0,0,N);
% Defining delta x
delx = diff(xGamma);
% Strength of the vortex sheet
gamma = 2*(alpha)*V_inf*((1 - xGamma/c)./(xGamma/c)).^0.5; 
% Defining the Strength of the Nth vortex
Gamma = gamma.*delx(1); 
%% Defining a function which calculates the radius.
% Radius function defined for use in polar coordinates
r= @(x,y,x1,y1) sqrt((x-x1).^2+(y-y1).^2);
%% Stream Function Calculation 
% Initializing stream function for allocation later
Total_Psi = 0;
% Calculating Psi for Uniform Flow based on the geometry for flow at a 12
% degree angle 
Psi_unif = -V_inf*x*sin(alpha) + V_inf*y*cos(alpha);

for i = 1:length(xGamma)
   % Calculating Psi for vortex flow
   Psi_vort = (Gamma(i)./(2*pi)).*log(r(x,y,xGamma(i),yGamma(i)));
   Total_Psi = Total_Psi + Psi_vort;
end 
    
% Adding Stream Functions using Superposition
Total_Psi = Total_Psi + Psi_unif;

%% Velocity Potential Calculation 
% Initializing total velocity potential
Total_Phi = 0;
% Defining velocity potential for uniform flow
Phi_unif = V_inf*x*cos(alpha) + V_inf*y*sin(alpha);
for i = 1:length(xGamma)
    Phi_vort = -Gamma(i)./(2*pi).*mod(atan2(y-yGamma(i),x-xGamma(i)),2*pi);
    Total_Phi = Total_Phi + Phi_vort;
end

% Adding velocity potentials using Superposition
Total_Phi = Total_Phi + Phi_unif;

%% Velocity and Pressure Calculations
% Initializing velocity in xy for vortex flow to be zero
V_vortx = 0; 
V_vorty = 0; 
% Initializing velocity in xy for uniform flow
V_unifx = ones(num_x) * V_inf*cos(alpha); 
V_unify = ones(num_y) * V_inf*sin(alpha);  

for i = 1:length(xGamma)
    % Velocity of Vortex in polar
    V_vort = -Gamma(i)./(2*pi*r(x,y,xGamma(i),yGamma(i))); 
    % Converting vortex velocities to cartesian
    V_vortx = V_vortx + V_vort.*cos((pi/2) + atan2(y - yGamma(i),x - xGamma(i)));  
    V_vorty = V_vorty + V_vort.*sin((pi/2) + atan2(y - yGamma(i),x - xGamma(i))); 
end
% Calculating magnitude of velocity at all points
Velocity = sqrt((V_vortx + V_unifx).^2 + (V_vorty + V_unify).^2);

%% Data Parsing to find min and max P and V values
Max_V = max(Velocity(:));
Min_V = min(Velocity(:));

%% Determine color levels for contours
% defines the color levels -> trial and error to find a good representation
levmin = Total_Psi(1,num_x); 
levmax = Total_Psi(num_y,num_x);
levels = linspace(levmin,levmax,100)';

%% Plotting using above data


% Plotting Stream Function
figure(pic)
subplot(2,1,1)
contourf(x,y,Total_Psi,levels)
% Drawing line to represent thin airfoil
line([0,c],[0,0],'linewidth', 3) ;
% Window of plot and labels
xlim([-0.5 2.25]);ylim([-1.5 1.5]);
title('Streamlines around Thin Airfoil');
xlabel('X Distance (m)');ylabel('Y Distance (m)');
colorbar

% Plotting Equipotential lines
figure(pic)
subplot(2,1,2)
contour(x,y,Total_Phi,levels)
% Drawing line to represent thin airfoil
line([0,c],[0,0],'linewidth', c) 
% Setting Window and labels
xlim([-1 2.25]);ylim([-1 1]);
title('Equipotential Lines around Thin Airfoil')
xlabel('X Distance (m)');ylabel('Y Distance (m)');
colorbar
sgtitle(['SL and EP Lines at c ',num2str(c),'m,angle ',num2str(alpha),' rads,and V_i_n_f ',num2str(V_inf),' m/s']);


end