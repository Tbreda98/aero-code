%% AERO COMP ASSIGNMENT 3: NACA AIRFOIL FUNCTION
%{
Author: Timothy Breda
Collaborators: Kyle Li
               Michael Vogel
               Sam Taylor
Objective: The objective of this code is to be able to generate x and y
           values for any NACA airfoil that is inputted.
%}

function [y,x] = NACA_airfoils(m,p,t,c,N)
%% Variable Explanation
%{

     c = chord length
     yt = half the thickness at a given value x
     t = maximum thickness as a fraction of the chord (last 2 digits of
     NACA XXXX (100 * t)
     m = maximum camber (first digit in NACA XXXX (100*m))
     p = location of max camber ( second digit in NACA XXXX (10*p))
     (x_u,y_u) and (x_l,y_l) = upper and lower surface
%}
% Defining the x domain
x_c = linspace(0,c,(N/2)+1);

% half thickness equation
y_t = (t/.2)*c*(.2969.*sqrt(x_c./c) - .1260.*(x_c./c) - .3516.*(x_c./c).^2 + .2843.*(x_c./c).^3 - .1036.*(x_c./c).^4);


% This for loop organizes y_c while the if statement ensures that the
% proper y_c is evaluated based on the distance to max camber, for the thin
% airfoil (NACA 0012), y_c(1) and dydx(1) are both set to zero to avoid NaN 
for i = 1:length(x_c)
    if  p*c == 0 && i == 1
        y_c(i) = 0;
        dydx(i) = 0;
    elseif    0 <= x_c(i) && x_c(i) <= p*c
        y_c(i) = m*(x_c(i)/(p^2))*(2*p - (x_c(i)/c));
        dydx(i) = (m*(2*p*c - 2*x_c(i)))/(c*p^2);
    elseif p*c <= x_c(i) && x_c(i) <= c
        y_c(i) = m*((c-x_c(i))/((1-p)^2)*(1+(x_c(i)/c)-2*p));
        dydx(i) = ((m*(-2*x_c(i)+2*c*p))/(c*((1-p)^2)));
    end
end

% getting xi
for i = 1:length(x_c)
   xi(i) = atan(dydx(i));
end

% Upper and lower surfaces
for i = 1:length(x_c)
    x_u(i) = x_c(i) - y_t(i)*sin(xi(i));
    y_u(i) = y_c(i) + y_t(i)*cos(xi(i));

    x_l(i) = x_c(i) + y_t(i)*sin(xi(i));
    y_l(i) = y_c(i) - y_t(i)*cos(xi(i));
end

% these lines are flipping some vectors to ensure that plotting starts from
% TE and goes counter clockwise
y_flipup = flip(y_u);
x_flip = flip(x_c);
y = zeros(1,N+1);
x = zeros(1,N+1);

% Concatenating the upper and lower y values into 1 vector

% NOTE: every number in x vec should repeat except for 0
y(1:N/2) = y_flipup(1:N/2);
x(1:N/2+1) = x_flip(1:N/2+1);
y((N/2)+1:N+1) = y_l(1:end); 
x((N/2)+1:N+1) = x_c(1:end);




%  for i = 1:2*N
%      % if statement here is to switch from 
%      if i <= N
%      % these vectors will be the ones plotted in script
%      y(i) = y_flipup(i);
%      x(i) = x_flip(i);
%      else
%      y(i) = y_l(i-N); 
%      x(i) = x_c(i-N);
%      end
%  end
%  
 
end



