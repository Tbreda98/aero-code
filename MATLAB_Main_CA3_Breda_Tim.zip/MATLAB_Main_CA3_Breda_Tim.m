%% COMP ASSIGNMENT 3: MAIN SCRIPT
%{
Author: Timothy Breda
Collaborators: Kyle Li
               Michael Vogel
               Sam Taylor
Objective: The objective of this code it to be able to output CP values for
various airfoils at various angles of attack. Once this is accomplished,
the code will then us those values along with other data from subfunctions
in order to find lift slopes and plot lift vs angle of attack.
%}
tic
%% Housekeeping
clc;clear;close all;

%% Airfoil Variables

% Number of Panels
N = 600;
% Chord Length (m)
c = 1;
alpha_vec = linspace(-5,10,4)*pi/180;
% Defining NACA 0012, 2412, 4412, 2424
NACA = [ 0 0 12; 2 4 12; 4 4 12; 2 4 24;];
NACA_str = {'NACA 0012','NACA 2412','NACA 4412','NACA 2424'};

%% Flow Variables
V_inf = 50; %(m/s)


%% Problem #1: Applying the Vortex Panel Method and Problem #2: Error and plots

problem = 1;

% Preallocation
c_l_mat = zeros(length(NACA),length(alpha_vec));
L_mat = zeros(length(NACA),length(alpha_vec));
% Looping through every airfoil
for i = 1:length(NACA)
    m = NACA(i,1)/100;
    p = NACA(i,2)/10;
    t = NACA(i,3)/100;
    [y,x] = NACA_airfoils(m,p,t,c,N);
    % Looping through every angle 
    for j = 1:length(alpha_vec)
        alpha = alpha_vec(j);
        [c_l,L_prime,CP,X] = Vortex_Panel(x,y,N,V_inf,alpha,m,c);
        c_l_mat(i,j) = c_l;
        L_mat(i,j) = L_prime;
        if m == 0 
        %  Plotting CP vs X (midpoints) for 
            figure(1)
            hold on
            plot(X/c,CP,'*');
            title('C_p vs. x/c for NACA 0012');
            legend('CP at -5 deg AoA','CP at 0 deg AoA','CP at 5 deg AoA','CP at 10 deg AoA');
            xlabel('x/c');
            ylabel('C_p');
            ylim([-2,1.5]);
            hold off
        end
    end
end
%% Problem 2: Convergence and Error

% For this problem I define an absolute error of 10% and try to find an N
% value in which satisfies the condition told below of absolute error of
% 10%. We know that the slope for NACA 0012 should be about 2pi, so I have
% manually changed the N value until the tolerance was met.

disp('Upon trial and error from testing values for the slope (a_0) for ')
disp(' values of N between 100 and 1000 I recieved a value within my desired')
disp('tolerance of 10% absolute error. I chose absolute errror because we know')
disp('the slope of c_l vs AoA should be 2pi for a thin airfoil, via Thin Airfoil Theory')
%% Problem #3: Plotting C_l vs. AoA
% preallocating vectors for slope and y int

% Plotting c_l vs alpha for each airfoil 
for i = 1:length(NACA)
[slope_yint] = polyfit(alpha_vec,c_l_mat(i,:),1);
a0(i) = slope_yint(1);
b_no(i) = slope_yint(2);
end
for i = 1:length(NACA)
    for j = 1:length(alpha_vec)
        c_l_mat_new(i,j) = a0(i)*alpha_vec(j) - b_no(i);
    end
end
for i = 1:length(NACA)
figure(2)
subplot(2,2,i)
plot(alpha_vec,c_l_mat_new(i,:));
xlabel('Angle of Attack (rads)');ylabel('Sectional Coefficient of Lift');
xlim([-.1 .2]); ylim([-.6 2]);
title(['Sectional C_l vs. AoA for ',NACA_str(i)]);
end
AoA_L0 = b_no./a0 *(180/pi);
disp('Discussion of zero lift angles of attack:')
disp('The zero lift angle of attack for NACA 0012 is approximately 0 (deg)')
disp('The zero lift angle of attack for NACA 2412 is approximately -2.189 (deg)')
disp('The zero lift angle of attack for NACA 4412 is approximately -4.271 (deg)')
disp('The zero lift angle of attack for NACA 2424 is approximately -2.228 (deg)')
disp('Discussion of lift slopes:')
disp('All of the airfoils besides the NACA 2424 have lift slopes of approximately')
disp('2pi, which holds well with thin airfoil theory which dictates a lift slope')
disp('of 2pi. It is expected that the thick airfoil (2424) has a higher lift slope')
disp('since it is not a thin airfoil and has a thickness of .24*c')
toc
 %% Functions Called
% The following functions were built and called as part of this assignment.
%
% <include>NACA_airfoils.m</include>
%
% <include>Vortex_Panel.m</include>