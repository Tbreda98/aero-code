function [c_l,L_prime,CP,X] = Vortex_Panel(x,y,N,V_inf,alpha,m,c)

%{
Author: Timothy Breda
Objective: THe objective of this function is to use the vortex panel method
to compute the coefficient of lift for several NACA airfoils.
%}
% y = [0,-.005,-.017,-.033,-.042,-.033,0,.045,.076,.072,.044,.013,0];
% x = [1,.933,.750,.500,.250,.067,0,.067,.250,.500,.750,.933,1];
% Remember to hard code y values and then remove

NP1 = N + 1;
y = -y;

for i = 1:N
    ip1 = i + 1;
    X(i) = .5*(x(i)+x(ip1));
    Y(i) = .5*(y(i)+y(ip1));
    S(i) = sqrt( (x(ip1)-x(i))^2 + (y(ip1)-y(i))^2);
    Theta(i) = atan2( (y(ip1)-y(i)),(x(ip1)-x(i)));
    sine(i) = sin(Theta(i));
    cosine(i) = cos(Theta(i));
    RHS(i) = sin(Theta(i) - alpha);
end

for i = 1:N
    for j = 1:N
        if i == j 
            CN1(i,j) = -1;
            CN2(i,j) = 1;
            CT1(i,j) = .5*pi;
            CT2(i,j) = .5*pi;
        else
            A = -(X(i)-x(j))*cosine(j) - (Y(i)-y(j))*sine(j);
            B = (X(i)-x(j))^2 + (Y(i)-y(j))^2;
            C = sin(Theta(i) - Theta(j));
            D = cos(Theta(i) - Theta(j));
            E = (X(i)-x(j))*sine(j) - (Y(i) - y(j))*cosine(j);
            F = log(1 + ((S(j)^2 + 2*A*S(j))/B));
            G = atan2((E*S(j)),(B+A*S(j)));
            P = (X(i)-x(j))*sin(Theta(i)-2*Theta(j)) ...
                + (Y(i)-y(j))*cos(Theta(i)-2*Theta(j));
            Q = (X(i)-x(j))*cos(Theta(i)-2*Theta(j)) ...
                - (Y(i)-y(j))*sin(Theta(i)-2*Theta(j));
            CN2(i,j) = D + .5*Q*F/S(j) - (A*C + D*E)*G/S(j);
            CN1(i,j) = .5*D*F + C*G - CN2(i,j);
            CT2(i,j) = C + .5*P*F/S(j) + (A*D-C*E)*G/S(j);
            CT1(i,j) = .5*C*F - D*G - CT2(i,j);
        end
    end
end
% Compute influence coefficients in Eqs(5.47) and (5.49)
AN = zeros(NP1);
AT = zeros(NP1);
for i = 1:N
    AN(i,1) = CN1(i,1);
    AN(i,NP1) = CN2(i,N);
    AT(i,1) = CT1(i,1);
    AT(i,NP1) = CT2(i,N);
    for j = 2:N
        AN(i,j) = CN1(i,j) + CN2(i,j-1);
        AT(i,j) = CT1(i,j) + CT2(i,j-1);
    end
end
%AT = -AT;
AN(NP1,1) = 1;
AN(NP1,NP1) = 1;
for j = 2:N
    AN(NP1,j) = 0;
end
RHS(NP1) = 0;
% Calling Cramer
Gama = linsolve(AN,RHS');
V = zeros(1,N);
CP = zeros(1,N);
for i = 1:N
    V(i) = cos(Theta(i) - alpha);
    for j = 1:NP1
        V(i) = V(i) + AT(i,j)*Gama(j);
        CP(i) = 1 - V(i)^2;
    end
end

% Calculating Sectional Lift COefficient using Kutta Joukowski
% 4.82 and 4.83 in anderson                
rho_inf = 1.225; % (kg/m^2)
GAMA = 0;
S = [S S(1)];
for i = 1:NP1
    GAMA = GAMA + Gama(i)*S(i);
end

% Dimensionilizing Gamma as seen in Keuthe and Chow
GAMA = GAMA*2*pi*V_inf;
% Using basic equations to find c_l and Lprime
L_prime = rho_inf*V_inf.*GAMA;
q = .5*V_inf^2*rho_inf; % (Pa)
c_l = L_prime/q;


        

end
