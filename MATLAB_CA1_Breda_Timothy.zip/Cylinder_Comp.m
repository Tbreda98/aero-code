function [Total_Lift,Total_Drag,Lift,Drag,theta,Error_Lift,Error_Drag] = Cylinder_Comp(P_inf,q_inf,N,s)
%{

Author: Tim Breda
Purpose: To compute total lift and drag around cylinder profile

%}

% Theta
theta = linspace(0,2*pi,2*N+1)'; %(rads)
% c_p calculation
c_p = 1-4.*(sin(theta)).^2;
% Calculating the pressure at each point
P = (c_p.*q_inf) + P_inf;
% Lift Force and Drag Force
F_Lift = P.*sin(theta);
F_Drag = P.*cos(theta);

% Initializing total lift and drag
Total_Lift = 0;
Total_Drag = 0;
% h as defined in the Numerical Integration pdf
h = (2*pi)/(3*N);

for i = 2:2:length(theta)-1
  
    % Executing Simpsons Rule
    Lift = h*s*(F_Lift(i-1) + 4*F_Lift(i) + F_Lift(i+1));
    Drag = h*s*(F_Drag(i-1) + 4*F_Drag(i) + F_Drag(i+1));
    
    % Summing Lift and Drag for each panel
    Total_Lift = Total_Lift + Lift;
    Total_Drag = Total_Drag + Drag;
end
