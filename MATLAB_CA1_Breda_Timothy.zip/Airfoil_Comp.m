function  [L,D] = Airfoil_Comp(P_inf,q_inf,N,c,alpha);

%{
Author: Tim Breda
Purpose: The purpose of this code is to be able to figure out the number
of panels required in order to get the total lift and drag on the airfoil
due to a pressure distrobution and pressure difference between the upper
and lower surface of the airfoil.
%}

% Loading in cpmat
load('Data_CA1_Breda_Timothy.mat');

% A nested 4 loops is used here to redefine each variable per each
% iteration for multiple reasons, one reason is so that the dy (slope)
% changes per each iteration.

% Since lots of variables and computations depend upon the number of panels
% used, this nested for loop helps to keep every computation on the same
% path.
for j = 1:N

% x changes with each iteration to make sure vectors are being created
% accurately without error, for example the airfoil function produces
% a vector without having to use an anonymous function in the mail script.
x = linspace(0,c,j+1);
% airfoil thickness
t = 12/100;
dx = c/j;
% The airfoil function is 
SF = ((t.*c)./.2).*((.2969.*sqrt(x./c)) - .126.*(x./c) - .3516.*(x./c).^2 + ...
    .2843.*(x./c).^3 - .1036.*(x./c).^4);

% Evaluating the coefficient of pressure along some location x/c along the upper surface
cp_up = -fnval(Cp_upper, x/c)';
cp_low = -fnval(Cp_lower, x/c)';

% The total pressure on upper and lower surfaces are calculated by
% backsolving from the coefficient of pressure equation
P_up = (cp_up.*q_inf) + P_inf;
P_low = (cp_low.*q_inf) + P_inf;

% Initializing Normal and Axial Forces
Normal = 0;
Axial = 0;

for i = 1:j
   
    % dy here is calculated by using the airfoil function to find the slope
    % in between 2 subsequent points
    dy(i) = SF(i+1) - SF(i);
    dyl(i) = -dy(i);
    % Using the information from the pdf to calculate normal and axial
    % forces for the upper and lower surfaces
    Normal_Up =- ((P_up(i+1)+P_up(i))/2)*dx;
    Normal_Low = ((P_low(i+1)+P_low(i))/2)*dx;
    Axial_Up =- ((P_up(i+1)+P_up(i))/2).*dy(i);
    Axial_Low = -((P_low(i+1)+P_low(i))/2).*dyl(i);
    
    % Combining the normal and axial contributions from each surface into
    % one value per force
     Normal = Normal + (Normal_Up+Normal_Low);
     Axial = Axial + (Axial_Up+Axial_Low);
    
end
 % Finally, lift and drag can be calculated based on the definition for
 % each as given by Anderson in the textbook
    L(j) = Normal.*cos(alpha) - Axial.*sin(alpha);
    D(j) = Normal.*sin(alpha) + Axial.*cos(alpha);


end

