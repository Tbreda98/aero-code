%{
Name: Timothy Breda
Collaborators: Kyle Li
               Tyler Pirner
               Michael Vogel
               Sam Taylor
Date: 0/19/2019
Assignment: Computation Lab 1
Course: ASEN 3111 Aerodynamics

Purpose: The purpose of this code is to be able to analyze flow around an
         cylinder and NACA 0012 airfoil in a freestream

Assumptions: steady, Ideal flow (incompressible and inviscid)
%}

%% Housekeeping

clc;
clear;
close all;

%% Variable Declaration & Data Load Problem 1)
N = 10;  

% diameter and radius of cylinder
d = 1; %(m)
R = .5*d; %(m)
% Freestream properties
v_inf = 30; %(m/s)
rho_inf = 1.225; %(kg/m^3)
P_inf = 101.3e3; %(Pa)
q_inf = .5*rho_inf*v_inf^2; %(Pa)
% Arc Length
s = (2*pi*R)/N; %(m)

% Defining tolerance and initializing count to 0
tolerance = 10^-3;
count = 0;

%% Problem I: Cylinder

% This loop is to call the function at each iteration in order to obtain a
% vector of lift and drag values which will be used in the plotting.

% Tolerance is included to pass display the value of i aka N where the
% values converge to zero.
for i = 2:N
    [Total_Lift,Total_Drag,Lift,Drag,theta] = Cylinder_Comp(P_inf,q_inf,i,s);
    Lift(i-1) = Total_Lift;
    Drag(i-1) = Total_Drag;
    if tolerance > Total_Lift && tolerance > Total_Drag && count == 0
        disp('Number of Panels for Cylinder Computation:');
        disp(i);
        count = count + 1;
    end
end

% Plotting Lift and Drag for Cylindrical Airfoil
figure;
% Indicized to N-1 since vector must be the same length
plot(1:N-1,Lift);
title('Lift vs. Number of Panels');
xlabel('Number of Panels');
ylabel('Lift Force (N)');
figure;
plot(1:N-1,Drag);
title('Drag vs. Number of Panels');
xlabel('Number of Panels');
ylabel('Drag Force (N)');



%% Part II: Airfoil 
N = 1000;
% Chord Length
c = 2; %(m)

% Alpha converted to radians
alpha = 9*pi/180; %(rads)

% Airfoil Function Call
[L,D] = Airfoil_Comp(P_inf,q_inf,N,c,alpha);

% Relative Error Calculation
for i = 1:N-2
    % Here I am using 2 subsequent points to find relative error
    % since the actual value is unknown
    Relative_Error = abs(L(i)/L(i+1) - 1);
    % This if statement is to make sure that the value of convergence at
    % each percentage in known, and the number of panels is displayed
    if Relative_Error < .05 && count ==1
        disp('Airfoil Computation:');
        disp('# of Panels for Relative Error at 5%:');
        disp(i+1);
        Conv_x(1) = (i+1);
        Conv_y(1) = -L(i+1);
        count = count +1;
    elseif Relative_Error < .01 && count ==2
        disp('# of Panels for Relative Error at 1%:');
        disp(i+1);
        Conv_x(2) = (i+1);
        Conv_y(2) = -L(i+1);
        count = count+1;
    elseif Relative_Error < .001 && count ==3
        disp('# of Panels for Relative Error at .1%:');
        disp(i+1);
        Conv_x(3) = (i+1);
        Conv_y(3) = -L(i+1);
        count = count+1;
    end
end

% Plotting Airfoil Lift and Drag
figure(12)
plot(linspace(1,N,N),-L);
hold on;
plot(linspace(1,N,N),-D);
title('Lift and Drag vs. Number of Panels');
hold on;
plot(Conv_x(1),Conv_y(1),'*')
hold on;
plot(Conv_x(2),Conv_y(2),'*')
hold on;
plot(Conv_x(3),Conv_y(3),'*')
legend('Lift','Drag','5% Error','1% Error','0.1% Error');





